import { requireAuth } from "@/lib/auth/get-user"
import { createServerClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { ChevronLeft, Printer, Trophy, Award } from "lucide-react"
import { ResultsFilter } from "@/components/results-filter"
import { GenerateResultsButton } from "@/components/generate-results-button"

export const dynamic = "force-dynamic"

export default async function ResultsPage({
  searchParams,
}: {
  searchParams: Promise<{ class?: string; session?: string; term?: string }>
}) {
  await requireAuth(["super_admin", "admin", "teacher"])
  const params = await searchParams
  const supabase = await createServerClient()

  const { data: sessions } = await supabase
    .from("sessions")
    .select("id, name, is_active")
    .order("start_date", { ascending: false })

  const { data: terms } = await supabase
    .from("terms")
    .select("id, name, session_id, is_active")
    .order("start_date", { ascending: false })

  let selectedSession = params.session
  let selectedTerm = params.term

  if (!selectedSession) {
    const activeSession = sessions?.find((s: any) => s.is_active)
    selectedSession = activeSession?.id
  }

  if (!selectedTerm && selectedSession) {
    const activeTerm = terms?.find((t: any) => t.session_id === selectedSession && t.is_active)
    selectedTerm = activeTerm?.id
  }

  // Get all classes
  const { data: classes } = await supabase
    .from("classes")
    .select("*, sections(name)")
    .eq("is_active", true)
    .order("name")

  // Get results if class, session, and term selected
  let results = null
  let classAverage = 0
  let highestAverage = 0
  let passRate = 0

  if (params.class && selectedSession && selectedTerm) {
    const { data, error } = await supabase
      .from("student_results")
      .select(`
        *,
        students (
          id,
          student_id,
          first_name,
          middle_name,
          last_name
        )
      `)
      .eq("class_id", params.class)
      .eq("session_id", selectedSession)
      .eq("term_id", selectedTerm)
      .order("position")

    results = data || []

    if (results.length > 0) {
      const totalStudents = results.length
      classAverage = results.reduce((acc: number, r: any) => acc + (r.average_score || 0), 0) / totalStudents
      highestAverage = Math.max(...results.map((r: any) => r.average_score || 0))
      const passCount = results.filter((r: any) => (r.subjects_failed || 0) === 0).length
      passRate = (passCount / totalStudents) * 100
    }
  }

  const hasResults = results && results.length > 0

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Link href="/assessments" className="flex mt-3 items-center gap-1.5 text-foreground hover:opacity-80 transition-opacity">
            <ChevronLeft className="h-6 w-6" />
            <h1 className="text-xl font-bold tracking-tight">View results</h1>
          </Link>
        </div>

        {params.class && selectedSession && selectedTerm && (
          <GenerateResultsButton
            classId={params.class}
            sessionId={selectedSession}
            termId={selectedTerm}
            hasResults={!!hasResults}
          />
        )}
      </div>

      <ResultsFilter
        sessions={sessions || []}
        terms={terms || []}
        classes={classes || []}
        defaultSession={selectedSession}
        defaultTerm={selectedTerm}
      />

      {params.class && selectedSession && selectedTerm && (!results || results.length === 0) && (
        <Card>
          <CardContent className="pt-6 flex flex-col items-center justify-center py-10 space-y-4">
            <p className="text-muted-foreground text-center">
              No results found for the selected class, session, and term. Results need to be generated first from
              student scores.
            </p>
            <GenerateResultsButton
              classId={params.class}
              sessionId={selectedSession}
              termId={selectedTerm}
              hasResults={false}
            />
          </CardContent>
        </Card>
      )}

      {results && results.length > 0 && (
        <Card className="gap-0 bg-secondary/40 dark:bg-secondary/10  border border-zinc-200 dark:border-zinc-800 shadow-none rounded-xl overflow-hidden">
          <CardHeader className="pb-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <CardTitle className="text-xl font-bold">Class Results</CardTitle>
                <CardDescription className="text-zinc-500">{results.length} student(s) in class</CardDescription>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Link href={`/assessments/results/finalize?session=${selectedSession}&term=${selectedTerm}&class=${params.class}`}>
                  <Button size="sm" variant="outline" className="h-9 text-xs font-bold border-zinc-200 dark:border-zinc-800 shadow-xs bg-white dark:bg-zinc-950 flex items-center gap-1.5 mr-2">
                    <Award className="h-4 w-4 text-primary shrink-0" />
                    Finalize & Evaluate Skills
                  </Button>
                </Link>

                <div className="bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 px-3 py-1.5 rounded-lg flex items-center gap-2 shadow-xs">
                  <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Avg</span>
                  <span className="text-sm font-black">{classAverage.toFixed(1)}%</span>
                </div>
                <div className="bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 px-3 py-1.5 rounded-lg flex items-center gap-2 shadow-xs">
                  <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Top</span>
                  <span className="text-sm font-black text-amber-500">{highestAverage.toFixed(1)}%</span>
                </div>
                <div className="bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 px-3 py-1.5 rounded-lg flex items-center gap-2 shadow-xs">
                  <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Pass</span>
                  <span className="text-sm font-black text-emerald-600 dark:text-emerald-500">{passRate.toFixed(0)}%</span>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="px-0 sm:px-0">
            <div className="overflow-x-auto border-t border-zinc-200/60 dark:border-zinc-800/60 pt-2 sm:pt-0 sm:border-none">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                    <th className="text-left p-3">Position</th>
                    <th className="text-left p-3">Student ID</th>
                    <th className="text-left p-3">Name</th>
                    <th className="text-center p-3">Total Score</th>
                    <th className="text-center p-3">Average</th>
                    <th className="text-center p-3">Subjects</th>
                    <th className="text-center p-3">Passed</th>
                    <th className="text-center p-3">Failed</th>
                    <th className="text-left p-3">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-900">
                  {results.map((result: any) => (
                    <tr 
                      key={result.id} 
                      className="border-b border-zinc-200/50 dark:border-zinc-800/50 bg-white dark:bg-zinc-950/40 hover:bg-zinc-50/50 dark:hover:bg-zinc-950/80 transition-colors"
                    >
                      <td className="p-3">
                        {result.position === 1 ? (
                          <span className="flex items-center gap-1 font-bold text-amber-500">
                            <Trophy className="h-4 w-4 fill-amber-500 shrink-0" />
                            <span>1st</span>
                          </span>
                        ) : result.position === 2 ? (
                          <span className="flex items-center gap-1 font-bold text-zinc-400">
                            <Trophy className="h-4 w-4 fill-zinc-400 shrink-0" />
                            <span>2nd</span>
                          </span>
                        ) : result.position === 3 ? (
                          <span className="flex items-center gap-1 font-bold text-amber-700">
                            <Trophy className="h-4 w-4 fill-amber-700 shrink-0" />
                            <span>3rd</span>
                          </span>
                        ) : (
                          <Badge variant="outline" className="font-bold border-zinc-200 dark:border-zinc-800 text-[10px]">
                            {result.position}
                          </Badge>
                        )}
                      </td>
                      <td className="p-3 font-semibold text-xs text-zinc-600 dark:text-zinc-300">
                        {result.students.student_id}
                      </td>
                      <td className="p-3 font-bold text-sm">
                        {result.students.first_name} {result.students.middle_name ? `${result.students.middle_name} ` : ''}{result.students.last_name}
                      </td>
                      <td className="p-3 text-center font-bold text-sm text-zinc-800 dark:text-zinc-200">
                        {result.total_score?.toFixed(1) || "0.0"}
                      </td>
                      <td className="p-3 text-center font-semibold text-xs text-zinc-700 dark:text-zinc-300">
                        {result.average_score?.toFixed(1) || "0.0"}%
                      </td>
                      <td className="p-3 text-center font-bold text-xs">
                        {result.total_subjects || 0}
                      </td>
                      <td className="p-3 text-center text-green-600 font-bold text-xs">
                        {result.subjects_passed || 0}
                      </td>
                      <td className="p-3 text-center text-red-600 font-bold text-xs">
                        {result.subjects_failed || 0}
                      </td>
                      <td className="p-3">
                        <Link
                          href={`/assessments/results/${result.student_id}?session=${selectedSession}&term=${selectedTerm}`}
                        >
                          <Button size="sm" variant="outline" className="h-8 text-xs bg-white dark:bg-zinc-950 font-bold border-zinc-200 dark:border-zinc-800 shadow-xs">
                            <Printer className="h-3.5 w-3.5 mr-1.5" />
                            View Report
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
